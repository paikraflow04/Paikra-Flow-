# 🚀 Paikra Flow — AI Content Repurposer

Made by **Manendra Paikra** | Ambikapur, Chhattisgarh

---

## 📦 Project Structure

```
paikraflow/
├── pages/
│   ├── _app.js          # App wrapper
│   ├── _document.js     # HTML head + SEO meta tags
│   ├── index.js         # Main website (Home + Tool + Pricing)
│   └── api/
│       └── repurpose.js # Claude AI API backend
├── styles/
│   └── globals.css      # Global styles + animations
├── public/              # Static files (add favicon here)
├── .env.local           # API key (DO NOT commit this)
├── next.config.js       # Next.js config
├── package.json         # Dependencies
└── README.md            # This file
```

---

## 🔑 Step 1 — Get Claude API Key (FREE)

1. Go to → https://console.anthropic.com
2. Sign up / Login
3. Click "API Keys" → "Create Key"
4. Copy your API key

---

## 💻 Step 2 — Run Locally

```bash
# Install dependencies
npm install

# Add your API key to .env.local
ANTHROPIC_API_KEY=sk-ant-your-key-here

# Start development server
npm run dev

# Open http://localhost:3000
```

---

## 🌐 Step 3 — Deploy to Vercel (FREE)

### Option A — GitHub + Vercel (Recommended)

1. Create GitHub account → github.com
2. Create new repository "paikraflow"
3. Upload all these files to GitHub
4. Go to → vercel.com
5. Login with GitHub
6. Click "New Project" → Import your repo
7. Add Environment Variable:
   - Key: `ANTHROPIC_API_KEY`
   - Value: `sk-ant-your-key-here`
8. Click "Deploy"
9. Your site is LIVE! 🎉

### Option B — Vercel CLI

```bash
npm install -g vercel
vercel login
vercel --prod
```

---

## 🌍 Step 4 — Add Custom Domain

### Buy Domain:
- **paikraflow.com** → GoDaddy/Namecheap (~₹500-800/year)
- **paikraflow.in** → Hostinger (~₹299/year)
- **paikraflow.tools** → Namecheap (~₹800/year)

### Connect Domain to Vercel:
1. Go to Vercel Dashboard → Your Project
2. Settings → Domains
3. Add your domain (e.g., paikraflow.com)
4. Copy the DNS records Vercel shows
5. Go to your domain provider (GoDaddy/Namecheap)
6. Add those DNS records
7. Wait 24-48 hours → Done! ✅

---

## 📈 Step 5 — Google Ranking (SEO)

### Submit to Google Search Console:
1. Go to → search.google.com/search-console
2. Add your domain
3. Verify ownership
4. Submit sitemap: yourdomain.com/sitemap.xml

### Quick SEO Tips:
- Write blog posts about your tool
- Make YouTube tutorial on Paikra Flow channel
- Share on social media
- Add tool to directories:
  - ProductHunt.com
  - IndieHackers.com
  - tools.so

---

## 💰 Monetization Setup

### 1. Real Payment Gateway (Razorpay - Indian):
- Sign up → razorpay.com (free for Indian businesses)
- Replace the demo "activatePro" button with Razorpay checkout
- Handle webhook to update user's Pro status

### 2. Google AdSense:
- Apply → adsense.google.com
- Add ad code to pages

### 3. Affiliate Links:
- Add affiliate links in results (Canva, ElevenLabs, etc.)

---

## 🛠️ Customization

### Change pricing:
In `pages/index.js` → find `FREE_LIMIT = 5` → change number

### Add/Remove platforms:
In `pages/index.js` → find `PLATFORMS` array → add/remove

### Change brand name/colors:
In `pages/index.js` → search "PAIKRA FLOW" → change
Main colors: `#00e5ff` (cyan) + `#a259ff` (purple)

---

## ⚡ Tech Stack

- **Framework**: Next.js 14
- **AI**: Claude API (Anthropic)
- **Hosting**: Vercel (Free)
- **Styling**: Pure CSS (no Tailwind needed)
- **Cost**: ~₹0/month (Vercel free + Claude API pay-per-use)

---

## 📱 Features

- ✅ Home Page (Hero + Stats + How it works)
- ✅ Tool Page (Content repurposer - 7 platforms)
- ✅ Pricing Page (Free vs Pro)
- ✅ Free/Pro limit system
- ✅ Upgrade modal
- ✅ SEO meta tags
- ✅ Mobile responsive
- ✅ Premium animations
- ✅ Copy to clipboard
- ✅ Typewriter effect
- ✅ Your name in footer 🎉

---

**Bhai all the best! Paikra Flow jaayega viral! 🚀🔥**

*Made with ❤️ by Manendra Paikra · Ambikapur, Chhattisgarh*
