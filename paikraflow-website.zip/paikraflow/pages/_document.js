import { Html, Head, Main, NextScript } from 'next/document'

export default function Document() {
  return (
    <Html lang="en">
      <Head>
        <meta charSet="utf-8" />
        <meta name="description" content="Paikra Flow - AI Content Repurposer. Turn one content into 7 platform-ready posts instantly. Free to start." />
        <meta name="keywords" content="AI content repurposer, content creator tools, Instagram caption generator, YouTube description, social media AI" />
        <meta property="og:title" content="Paikra Flow - AI Content Repurposer" />
        <meta property="og:description" content="One Content. Seven Platforms. Zero Effort. AI-powered content repurposing tool." />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Paikra Flow - AI Content Repurposer" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  )
}
