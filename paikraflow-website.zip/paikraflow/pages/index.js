import { useState, useEffect, useRef } from "react";
import Head from "next/head";

const FREE_LIMIT = 5;
const PLATFORMS = [
  { id: "instagram", label: "Instagram Caption",  icon: "📸", color: "#E1306C" },
  { id: "twitter",   label: "Twitter/X Thread",   icon: "🐦", color: "#1DA1F2" },
  { id: "youtube",   label: "YouTube Description", icon: "▶️", color: "#FF0000" },
  { id: "reels",     label: "Reels Script",        icon: "🎬", color: "#FF6B35" },
  { id: "whatsapp",  label: "WhatsApp Status",     icon: "💬", color: "#25D366" },
  { id: "blog",      label: "Blog Outline",        icon: "📝", color: "#A259FF", pro: true },
  { id: "email",     label: "Email Newsletter",    icon: "📧", color: "#00E5FF", pro: true },
];
const TONES = ["Casual", "Professional", "Funny", "Inspirational", "Educational"];

function useTypewriter(text, speed = 10) {
  const [displayed, setDisplayed] = useState("");
  useEffect(() => {
    if (!text) { setDisplayed(""); return; }
    setDisplayed("");
    let i = 0;
    const t = setInterval(() => {
      setDisplayed(text.slice(0, i + 1));
      i++;
      if (i >= text.length) clearInterval(t);
    }, speed);
    return () => clearInterval(t);
  }, [text]);
  return displayed;
}

export default function Home() {
  const [page, setPage]                     = useState("home");
  const [input, setInput]                   = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState(["instagram", "twitter"]);
  const [tone, setTone]                     = useState("Casual");
  const [results, setResults]               = useState({});
  const [loading, setLoading]               = useState(false);
  const [loadingPlatform, setLoadingPlatform] = useState("");
  const [usageCount, setUsageCount]         = useState(0);
  const [isPro, setIsPro]                   = useState(false);
  const [activePlatform, setActivePlatform] = useState(null);
  const [copied, setCopied]                 = useState("");
  const [showUpgrade, setShowUpgrade]       = useState(false);
  const [mobileMenu, setMobileMenu]         = useState(false);
  const resultRef = useRef(null);

  useEffect(() => {
    const u = localStorage.getItem("pf_usage");
    const p = localStorage.getItem("pf_pro");
    if (u) setUsageCount(parseInt(u));
    if (p === "true") setIsPro(true);
  }, []);

  const activeResult   = results[activePlatform] || "";
  const displayed      = useTypewriter(activeResult, 8);
  const remainingUses  = Math.max(0, FREE_LIMIT - usageCount);

  const togglePlatform = (id) =>
    setSelectedPlatforms(prev =>
      prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]
    );

  const repurpose = async () => {
    if (!input.trim() || selectedPlatforms.length === 0) return;
    if (!isPro && usageCount >= FREE_LIMIT) { setShowUpgrade(true); return; }

    setLoading(true);
    setResults({});
    setActivePlatform(null);

    const newUsage = usageCount + 1;
    setUsageCount(newUsage);
    localStorage.setItem("pf_usage", newUsage);

    for (const pid of selectedPlatforms) {
      const platform = PLATFORMS.find(p => p.id === pid);
      setLoadingPlatform(platform.label);
      try {
        const res = await fetch("/api/repurpose", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content: input, platform: pid, tone }),
        });
        const data = await res.json();
        setResults(prev => ({ ...prev, [pid]: data.result || data.error }));
        if (!activePlatform) setActivePlatform(pid);
      } catch {
        setResults(prev => ({ ...prev, [pid]: "Error. Please try again." }));
      }
    }

    setLoading(false);
    setLoadingPlatform("");
    setTimeout(() => resultRef.current?.scrollIntoView({ behavior: "smooth" }), 100);
  };

  const copy = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(""), 2000);
  };

  const activatePro = () => {
    setIsPro(true);
    localStorage.setItem("pf_pro", "true");
    setShowUpgrade(false);
  };

  // ── JSX ─────────────────────────────────────────────────────────
  return (
    <>
      <Head>
        <title>Paikra Flow — AI Content Repurposer</title>
      </Head>

      <div style={{ minHeight: "100vh", background: "radial-gradient(ellipse at 15% 15%, rgba(0,229,255,0.04) 0%,transparent 55%), radial-gradient(ellipse at 85% 85%, rgba(162,89,255,0.04) 0%,transparent 55%), #06060f", position: "relative" }}>

        {/* Particles */}
        <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0, overflow: "hidden" }}>
          {[...Array(16)].map((_, i) => (
            <div key={i} style={{
              position: "absolute", borderRadius: "50%",
              width: i % 3 === 0 ? 3 : 2, height: i % 3 === 0 ? 3 : 2,
              background: i % 4 === 0 ? "#00e5ff" : i % 3 === 0 ? "#a259ff" : "rgba(255,255,255,0.25)",
              left: `${(i * 47 + 11) % 100}%`, top: `${(i * 71 + 5) % 100}%`,
              animation: `particle ${6 + (i % 4) * 1.5}s ease-in-out infinite`,
              animationDelay: `${i * 0.5}s`, opacity: 0.35 + (i % 5) * 0.1,
            }} />
          ))}
        </div>

        {/* ── NAV ──────────────────────────────────────────── */}
        <nav style={{
          position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
          background: "rgba(6,6,15,0.85)", backdropFilter: "blur(24px)",
          borderBottom: "1px solid rgba(255,255,255,0.05)",
          padding: "0 28px", height: 60,
          display: "flex", alignItems: "center", justifyContent: "space-between",
        }}>
          {/* Logo */}
          <div onClick={() => setPage("home")} style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer" }}>
            <div style={{
              width: 30, height: 30, borderRadius: 9,
              background: "linear-gradient(135deg,#00e5ff,#a259ff)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontFamily: "'Syne',sans-serif", fontWeight: 900, fontSize: 14, color: "#000",
            }}>P</div>
            <span style={{ fontFamily: "'Syne',sans-serif", fontWeight: 700, fontSize: 14, color: "#fff", letterSpacing: "0.05em" }}>
              PAIKRA <span style={{ color: "#00e5ff" }}>FLOW</span>
            </span>
          </div>

          {/* Desktop links */}
          <div style={{ display: "flex", gap: 28, alignItems: "center" }}>
            {["home","tool","pricing"].map(p => (
              <span key={p} onClick={() => setPage(p)} style={{
                color: page === p ? "#fff" : "rgba(255,255,255,0.4)",
                cursor: "pointer", fontSize: 13, fontWeight: 500,
                textTransform: "capitalize", transition: "color 0.2s",
                letterSpacing: "0.03em",
              }}>{p}</span>
            ))}
            {!isPro ? (
              <button onClick={() => setPage("pricing")} style={{
                background: "linear-gradient(135deg,#00e5ff,#a259ff)",
                color: "#000", border: "none", borderRadius: 10,
                padding: "7px 18px", fontSize: 12, fontWeight: 700,
                cursor: "pointer", fontFamily: "'Syne',sans-serif",
                animation: "glow 3s ease-in-out infinite",
              }}>Go Pro ⚡</button>
            ) : (
              <div style={{
                display: "inline-flex", gap: 6, background: "rgba(0,229,255,0.1)",
                border: "1px solid rgba(0,229,255,0.25)", borderRadius: 20,
                padding: "5px 14px", fontSize: 11, fontWeight: 700, color: "#00e5ff",
              }}>✓ PRO</div>
            )}
          </div>
        </nav>

        <div style={{ paddingTop: 60, position: "relative", zIndex: 1 }}>

          {/* ── HOME ─────────────────────────────────────── */}
          {page === "home" && (
            <div>
              {/* Hero */}
              <section style={{ maxWidth: 840, margin: "0 auto", padding: "90px 24px 64px", textAlign: "center" }}>
                <div style={{ animation: "fadeUp 0.6s ease both", marginBottom: 18 }}>
                  <div style={{
                    display: "inline-flex", gap: 6, background: "rgba(0,229,255,0.08)",
                    border: "1px solid rgba(0,229,255,0.18)", borderRadius: 20,
                    padding: "5px 16px", fontSize: 11, fontWeight: 700, color: "#00e5ff",
                    letterSpacing: "0.1em", textTransform: "uppercase",
                  }}>✦ AI-Powered Content Tool</div>
                </div>

                <h1 style={{
                  fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: "clamp(38px,7vw,68px)",
                  lineHeight: 1.05, letterSpacing: "-0.03em", color: "#fff",
                  animation: "fadeUp 0.7s ease both 0.1s", marginBottom: 22,
                }}>
                  One Content.<br />
                  <span style={{ background: "linear-gradient(135deg,#00e5ff,#a259ff)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                    Seven Platforms.
                  </span><br />
                  Zero Effort.
                </h1>

                <p style={{
                  color: "rgba(255,255,255,0.4)", fontSize: 16, lineHeight: 1.75,
                  maxWidth: 500, margin: "0 auto 36px",
                  animation: "fadeUp 0.8s ease both 0.2s",
                }}>
                  Paste your YouTube script, blog, or idea — Paikra Flow AI instantly creates content for Instagram, Twitter, Reels, WhatsApp & more.
                </p>

                <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap", animation: "fadeUp 0.9s ease both 0.3s" }}>
                  <button onClick={() => setPage("tool")} style={{
                    background: "linear-gradient(135deg,#00e5ff,#a259ff)", color: "#000",
                    border: "none", borderRadius: 14, padding: "14px 34px",
                    fontSize: 14, fontWeight: 700, cursor: "pointer",
                    fontFamily: "'Syne',sans-serif", animation: "glow 3s ease-in-out infinite",
                    transition: "transform 0.2s",
                  }} onMouseEnter={e => e.target.style.transform="translateY(-2px)"}
                     onMouseLeave={e => e.target.style.transform="translateY(0)"}>
                    Start Free →
                  </button>
                  <button onClick={() => setPage("pricing")} style={{
                    background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.65)",
                    border: "1px solid rgba(255,255,255,0.1)", borderRadius: 14,
                    padding: "14px 28px", fontSize: 14, fontWeight: 600, cursor: "pointer",
                    transition: "all 0.2s",
                  }}>View Pricing</button>
                </div>
                {!isPro && (
                  <p style={{ marginTop: 16, color: "rgba(255,255,255,0.2)", fontSize: 12, animation: "fadeUp 1s ease both 0.4s" }}>
                    {remainingUses} free uses remaining — no credit card needed
                  </p>
                )}
              </section>

              {/* Platform pills */}
              <section style={{ maxWidth: 680, margin: "0 auto", padding: "0 24px 56px" }}>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 10, justifyContent: "center" }}>
                  {PLATFORMS.map(p => (
                    <div key={p.id} style={{
                      display: "flex", alignItems: "center", gap: 8,
                      background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)",
                      borderRadius: 20, padding: "8px 16px",
                      fontSize: 13, color: "rgba(255,255,255,0.5)",
                    }}><span>{p.icon}</span> {p.label}</div>
                  ))}
                </div>
              </section>

              {/* Stats */}
              <section style={{ maxWidth: 720, margin: "0 auto 80px", padding: "0 24px" }}>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))", gap: 14 }}>
                  {[
                    ["7", "Platforms"],
                    ["10x", "Faster"],
                    ["Claude AI", "Powered"],
                    ["Free", "To Start"],
                  ].map(([val, label]) => (
                    <div key={label} style={{
                      background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)",
                      borderRadius: 20, padding: "26px 20px", textAlign: "center",
                    }}>
                      <div style={{ fontFamily: "'Syne',sans-serif", fontSize: 28, fontWeight: 800, color: "#fff", marginBottom: 4 }}>{val}</div>
                      <div style={{ fontSize: 11, color: "rgba(255,255,255,0.28)", letterSpacing: "0.1em", textTransform: "uppercase" }}>{label}</div>
                    </div>
                  ))}
                </div>
              </section>

              {/* How it works */}
              <section style={{ maxWidth: 720, margin: "0 auto 80px", padding: "0 24px" }}>
                <h2 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 700, fontSize: 26, textAlign: "center", marginBottom: 36, color: "#fff" }}>
                  How It Works
                </h2>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", gap: 16 }}>
                  {[
                    ["01", "Paste Content", "Add your script, blog post, or any content"],
                    ["02", "Pick Platforms", "Select where you want to post"],
                    ["03", "AI Generates", "Claude AI creates platform-perfect content"],
                    ["04", "Copy & Post", "One click copy — ready to publish!"],
                  ].map(([num, title, desc]) => (
                    <div key={num} style={{
                      background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)",
                      borderRadius: 18, padding: "22px 20px",
                    }}>
                      <div style={{ fontFamily: "'Syne',sans-serif", fontSize: 32, fontWeight: 800, color: "rgba(0,229,255,0.2)", marginBottom: 10 }}>{num}</div>
                      <div style={{ fontWeight: 600, fontSize: 14, color: "#fff", marginBottom: 6 }}>{title}</div>
                      <div style={{ fontSize: 12, color: "rgba(255,255,255,0.3)", lineHeight: 1.6 }}>{desc}</div>
                    </div>
                  ))}
                </div>
              </section>

              {/* CTA */}
              <section style={{ maxWidth: 540, margin: "0 auto 100px", padding: "0 24px", textAlign: "center" }}>
                <div style={{
                  background: "linear-gradient(135deg,rgba(0,229,255,0.06),rgba(162,89,255,0.06))",
                  border: "1px solid rgba(0,229,255,0.12)", borderRadius: 24, padding: "40px 32px",
                }}>
                  <h3 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 24, color: "#fff", marginBottom: 10 }}>
                    Ready to 10x your content?
                  </h3>
                  <p style={{ color: "rgba(255,255,255,0.35)", fontSize: 13, marginBottom: 24 }}>
                    Join creators using Paikra Flow to save hours every week.
                  </p>
                  <button onClick={() => setPage("tool")} style={{
                    background: "linear-gradient(135deg,#00e5ff,#a259ff)", color: "#000",
                    border: "none", borderRadius: 14, padding: "13px 32px",
                    fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "'Syne',sans-serif",
                    animation: "glow 3s ease-in-out infinite",
                  }}>Try Free Now →</button>
                </div>
              </section>
            </div>
          )}

          {/* ── TOOL ──────────────────────────────────────── */}
          {page === "tool" && (
            <div style={{ maxWidth: 700, margin: "0 auto", padding: "44px 20px 80px" }}>
              <div style={{ marginBottom: 28 }}>
                <div style={{
                  display: "inline-flex", gap: 6, background: "rgba(0,229,255,0.08)",
                  border: "1px solid rgba(0,229,255,0.18)", borderRadius: 20,
                  padding: "5px 14px", fontSize: 11, fontWeight: 700, color: "#00e5ff",
                  letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 12,
                }}>✦ Content Repurposer</div>
                <h2 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 700, fontSize: 24, color: "#fff", marginBottom: 6 }}>
                  Repurpose Your Content
                </h2>
                <p style={{ color: "rgba(255,255,255,0.3)", fontSize: 12 }}>
                  {!isPro ? `${remainingUses}/${FREE_LIMIT} free uses left` : "✓ Pro — Unlimited uses"}
                </p>
              </div>

              {/* Content input */}
              <div style={{ marginBottom: 22 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.28)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 8, display: "block" }}>
                  Your Content
                </label>
                <textarea
                  rows={5}
                  placeholder="Paste your YouTube script, blog post, idea, or any content here..."
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  style={{
                    width: "100%", background: "rgba(255,255,255,0.03)",
                    border: "1.5px solid rgba(255,255,255,0.08)", borderRadius: 16,
                    padding: "18px", color: "#fff", fontSize: 14, resize: "none", outline: "none",
                    lineHeight: 1.7, transition: "border-color 0.3s", fontFamily: "'DM Sans',sans-serif",
                  }}
                  onFocus={e => e.target.style.borderColor = "rgba(0,229,255,0.3)"}
                  onBlur={e => e.target.style.borderColor = "rgba(255,255,255,0.08)"}
                />
                <div style={{ textAlign: "right", fontSize: 11, color: "rgba(255,255,255,0.18)", marginTop: 5 }}>{input.length} chars</div>
              </div>

              {/* Tone */}
              <div style={{ marginBottom: 22 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.28)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 8, display: "block" }}>
                  Tone
                </label>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                  {TONES.map(t => (
                    <div key={t} onClick={() => setTone(t)} style={{
                      padding: "7px 16px", borderRadius: 10, cursor: "pointer", fontSize: 12, fontWeight: 600,
                      background: tone === t ? "linear-gradient(135deg,#00e5ff,#a259ff)" : "rgba(255,255,255,0.04)",
                      color: tone === t ? "#000" : "rgba(255,255,255,0.45)",
                      border: tone === t ? "none" : "1px solid rgba(255,255,255,0.07)",
                      transition: "all 0.2s",
                    }}>{t}</div>
                  ))}
                </div>
              </div>

              {/* Platforms */}
              <div style={{ marginBottom: 26 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.28)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 10, display: "block" }}>
                  Platforms ({selectedPlatforms.length} selected)
                </label>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(190px,1fr))", gap: 9 }}>
                  {PLATFORMS.map(p => {
                    const isActive = selectedPlatforms.includes(p.id);
                    const isLocked = p.pro && !isPro;
                    return (
                      <div key={p.id} onClick={() => !isLocked && togglePlatform(p.id)} style={{
                        borderRadius: 14, padding: "13px 16px", cursor: isLocked ? "not-allowed" : "pointer",
                        transition: "all 0.2s", display: "flex", alignItems: "center", gap: 11,
                        border: isActive ? "1.5px solid rgba(0,229,255,0.4)" : "1.5px solid rgba(255,255,255,0.06)",
                        background: isActive ? "rgba(0,229,255,0.05)" : "rgba(255,255,255,0.02)",
                        opacity: isLocked ? 0.4 : 1,
                      }}>
                        <span style={{ fontSize: 18 }}>{p.icon}</span>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: 12, fontWeight: 600, color: isActive ? "#fff" : "rgba(255,255,255,0.5)" }}>{p.label}</div>
                          {isLocked && <div style={{ fontSize: 10, color: "rgba(255,255,255,0.22)", marginTop: 1 }}>Pro only 🔒</div>}
                        </div>
                        {isActive && <div style={{ width: 7, height: 7, borderRadius: "50%", background: "#00e5ff" }} />}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Generate */}
              <button
                onClick={repurpose}
                disabled={loading || !input.trim() || selectedPlatforms.length === 0}
                style={{
                  width: "100%", background: loading || !input.trim() ? "rgba(255,255,255,0.05)" : "linear-gradient(135deg,#00e5ff,#a259ff)",
                  color: loading || !input.trim() ? "rgba(255,255,255,0.3)" : "#000",
                  border: "none", borderRadius: 16, padding: "16px",
                  fontSize: 15, fontWeight: 700, cursor: loading || !input.trim() ? "not-allowed" : "pointer",
                  fontFamily: "'Syne',sans-serif", transition: "all 0.3s",
                  animation: !loading && input.trim() ? "glow 3s ease-in-out infinite" : "none",
                }}
              >
                {loading ? (
                  <span style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 10 }}>
                    <span style={{ width: 18, height: 18, border: "2px solid rgba(0,229,255,0.2)", borderTop: "2px solid #00e5ff", borderRadius: "50%", display: "inline-block", animation: "spin 0.8s linear infinite" }} />
                    Generating {loadingPlatform}...
                  </span>
                ) : `✦ Repurpose for ${selectedPlatforms.length} Platform${selectedPlatforms.length !== 1 ? "s" : ""} →`}
              </button>

              {/* Results */}
              {Object.keys(results).length > 0 && (
                <div ref={resultRef} style={{ marginTop: 40 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.28)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 14 }}>
                    Your Results
                  </div>

                  {/* Tabs */}
                  <div style={{ display: "flex", gap: 8, overflowX: "auto", marginBottom: 18, paddingBottom: 4 }}>
                    {selectedPlatforms.filter(pid => results[pid]).map(pid => {
                      const p = PLATFORMS.find(pl => pl.id === pid);
                      const isActive = activePlatform === pid;
                      return (
                        <button key={pid} onClick={() => setActivePlatform(pid)} style={{
                          padding: "9px 16px", borderRadius: 10, cursor: "pointer", fontSize: 12, fontWeight: 600,
                          whiteSpace: "nowrap", border: "1.5px solid",
                          background: isActive ? `linear-gradient(135deg,${p.color},#a259ff)` : "transparent",
                          color: isActive ? "#fff" : "rgba(255,255,255,0.35)",
                          borderColor: isActive ? "transparent" : "rgba(255,255,255,0.07)",
                          transition: "all 0.2s",
                        }}>{p.icon} {p.label.split(" ")[0]}</button>
                      );
                    })}
                  </div>

                  {/* Result content */}
                  {activePlatform && results[activePlatform] && (
                    <div style={{
                      background: "rgba(255,255,255,0.02)", border: "1.5px solid rgba(255,255,255,0.07)",
                      borderRadius: 18, padding: "24px 24px 24px 24px", position: "relative",
                      animation: "slideIn 0.3s ease",
                    }}>
                      <button onClick={() => copy(results[activePlatform], activePlatform)} style={{
                        position: "absolute", top: 16, right: 16,
                        background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.6)",
                        border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8,
                        padding: "5px 12px", fontSize: 11, fontWeight: 600, cursor: "pointer",
                      }}>{copied === activePlatform ? "✓ Copied!" : "Copy"}</button>
                      <div style={{
                        color: "rgba(255,255,255,0.8)", fontSize: 13, lineHeight: 1.8,
                        whiteSpace: "pre-wrap", wordBreak: "break-word", paddingRight: 70, marginTop: 4,
                      }}>{displayed}</div>
                    </div>
                  )}

                  <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
                    <button onClick={() => { setResults({}); setActivePlatform(null); }} style={{
                      flex: 1, background: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.55)",
                      border: "1px solid rgba(255,255,255,0.08)", borderRadius: 12,
                      padding: "11px", fontSize: 13, fontWeight: 600, cursor: "pointer",
                    }}>← New Content</button>
                    {!isPro && (
                      <button onClick={() => setPage("pricing")} style={{
                        flex: 1, background: "linear-gradient(135deg,#00e5ff,#a259ff)", color: "#000",
                        border: "none", borderRadius: 12, padding: "11px",
                        fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "'Syne',sans-serif",
                      }}>Upgrade Pro ⚡</button>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ── PRICING ───────────────────────────────────── */}
          {page === "pricing" && (
            <div style={{ maxWidth: 740, margin: "0 auto", padding: "60px 20px 80px" }}>
              <div style={{ textAlign: "center", marginBottom: 48 }}>
                <div style={{
                  display: "inline-flex", gap: 6, background: "rgba(0,229,255,0.08)",
                  border: "1px solid rgba(0,229,255,0.18)", borderRadius: 20,
                  padding: "5px 14px", fontSize: 11, fontWeight: 700, color: "#00e5ff",
                  letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 16,
                }}>✦ Pricing</div>
                <h2 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 38, color: "#fff", marginBottom: 10 }}>
                  Simple, Honest Pricing
                </h2>
                <p style={{ color: "rgba(255,255,255,0.3)", fontSize: 14 }}>Start free. Upgrade when you need more.</p>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))", gap: 18, marginBottom: 52 }}>
                {/* Free Card */}
                <div style={{
                  borderRadius: 22, padding: "30px 26px",
                  background: "rgba(255,255,255,0.02)", border: "1.5px solid rgba(255,255,255,0.07)",
                }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,0.3)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 14 }}>Free</div>
                  <div style={{ fontFamily: "'Syne',sans-serif", fontSize: 42, fontWeight: 800, color: "#fff", marginBottom: 4 }}>₹0</div>
                  <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 12, marginBottom: 26 }}>Forever free</div>
                  {[`${FREE_LIMIT} repurposes/month`, "5 platforms", "3 tones", "Basic support"].map(f => (
                    <div key={f} style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 11, fontSize: 13, color: "rgba(255,255,255,0.5)" }}>
                      <span style={{ color: "#00e5ff" }}>✓</span> {f}
                    </div>
                  ))}
                  <button onClick={() => setPage("tool")} style={{
                    width: "100%", marginTop: 20, background: "rgba(255,255,255,0.05)",
                    color: "rgba(255,255,255,0.6)", border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: 12, padding: "12px", fontSize: 13, fontWeight: 600, cursor: "pointer",
                  }}>Get Started Free</button>
                </div>

                {/* Pro Card */}
                <div style={{
                  borderRadius: 22, padding: "30px 26px", position: "relative", overflow: "hidden",
                  background: "linear-gradient(135deg,rgba(0,229,255,0.07),rgba(162,89,255,0.07))",
                  border: "1.5px solid rgba(0,229,255,0.22)",
                  boxShadow: "0 0 50px rgba(0,229,255,0.06)",
                }}>
                  <div style={{
                    position: "absolute", top: 0, right: 24,
                    background: "linear-gradient(135deg,#00e5ff,#a259ff)",
                    borderRadius: "0 0 10px 10px", padding: "3px 12px",
                    fontSize: 9, fontWeight: 700, color: "#000", letterSpacing: "0.1em", textTransform: "uppercase",
                  }}>POPULAR</div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: "#00e5ff", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 14 }}>Pro</div>
                  <div style={{ fontFamily: "'Syne',sans-serif", fontSize: 42, fontWeight: 800, color: "#fff", marginBottom: 4 }}>
                    ₹299<span style={{ fontSize: 16, color: "rgba(255,255,255,0.35)" }}>/month</span>
                  </div>
                  <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 12, marginBottom: 26 }}>Cancel anytime</div>
                  {["Unlimited repurposes", "All 7 platforms", "All 5 tones", "Blog & Email content", "Priority AI speed", "New features first"].map(f => (
                    <div key={f} style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 11, fontSize: 13, color: "rgba(255,255,255,0.75)" }}>
                      <span style={{ color: "#00e5ff" }}>✓</span> {f}
                    </div>
                  ))}
                  <button onClick={activatePro} style={{
                    width: "100%", marginTop: 20,
                    background: "linear-gradient(135deg,#00e5ff,#a259ff)",
                    color: "#000", border: "none", borderRadius: 12, padding: "13px",
                    fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "'Syne',sans-serif",
                    animation: "glow 3s ease-in-out infinite",
                  }}>{isPro ? "✓ Current Plan" : "Upgrade to Pro ⚡"}</button>
                  <div style={{ textAlign: "center", fontSize: 10, color: "rgba(255,255,255,0.15)", marginTop: 10 }}>
                    Demo mode: click to activate Pro
                  </div>
                </div>
              </div>

              {/* FAQ */}
              <div>
                <h3 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 700, fontSize: 20, color: "#fff", marginBottom: 24, textAlign: "center" }}>FAQ</h3>
                {[
                  ["Is it really free?", "Yes! You get 5 free repurposes every month with no credit card required."],
                  ["What AI powers this?", "Paikra Flow is powered by Claude AI — one of the world's most advanced language models."],
                  ["Can I cancel anytime?", "Absolutely. Cancel with one click, no questions asked, no hidden fees."],
                  ["How many platforms?", "5 platforms on Free plan, all 7 (including Blog & Email) on Pro."],
                  ["Does it support Hindi?", "Yes! Input content in Hindi or English — the AI understands both."],
                ].map(([q, a]) => (
                  <div key={q} style={{ borderBottom: "1px solid rgba(255,255,255,0.05)", padding: "16px 0" }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: "rgba(255,255,255,0.75)", marginBottom: 5 }}>{q}</div>
                    <div style={{ fontSize: 13, color: "rgba(255,255,255,0.3)", lineHeight: 1.6 }}>{a}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <footer style={{
          borderTop: "1px solid rgba(255,255,255,0.05)", padding: "24px",
          textAlign: "center", position: "relative", zIndex: 1,
        }}>
          <div style={{ fontFamily: "'Syne',sans-serif", fontWeight: 700, fontSize: 13, color: "rgba(255,255,255,0.25)", marginBottom: 4 }}>
            PAIKRA <span style={{ color: "rgba(0,229,255,0.4)" }}>FLOW</span>
          </div>
          <div style={{ fontSize: 11, color: "rgba(255,255,255,0.15)" }}>
            Made with ❤️ by Manendra Paikra · Ambikapur, Chhattisgarh
          </div>
        </footer>

        {/* Upgrade Modal */}
        {showUpgrade && (
          <div style={{
            position: "fixed", inset: 0, background: "rgba(0,0,0,0.88)", zIndex: 200,
            display: "flex", alignItems: "center", justifyContent: "center", padding: 20,
          }}>
            <div style={{
              background: "#0a0a18", border: "1.5px solid rgba(0,229,255,0.18)",
              borderRadius: 22, padding: 36, maxWidth: 380, width: "100%", textAlign: "center",
              boxShadow: "0 0 60px rgba(0,229,255,0.08)",
            }}>
              <div style={{ fontSize: 38, marginBottom: 14 }}>⚡</div>
              <h3 style={{ fontFamily: "'Syne',sans-serif", fontSize: 22, fontWeight: 800, color: "#fff", marginBottom: 10 }}>Free Limit Reached!</h3>
              <p style={{ color: "rgba(255,255,255,0.35)", fontSize: 13, marginBottom: 26, lineHeight: 1.65 }}>
                You've used all {FREE_LIMIT} free repurposes. Upgrade to Pro for unlimited access to all 7 platforms.
              </p>
              <button onClick={() => { activatePro(); setPage("tool"); }} style={{
                width: "100%", marginBottom: 10,
                background: "linear-gradient(135deg,#00e5ff,#a259ff)", color: "#000",
                border: "none", borderRadius: 13, padding: "13px",
                fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "'Syne',sans-serif",
              }}>Upgrade to Pro — ₹299/month ⚡</button>
              <button onClick={() => setShowUpgrade(false)} style={{
                width: "100%", background: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.4)",
                border: "1px solid rgba(255,255,255,0.08)", borderRadius: 13, padding: "12px",
                fontSize: 13, fontWeight: 600, cursor: "pointer",
              }}>Maybe Later</button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
