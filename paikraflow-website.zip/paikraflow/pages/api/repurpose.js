export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { content, platform, tone } = req.body;
  if (!content || !platform || !tone) return res.status(400).json({ error: "Missing fields" });

  const prompts = {
    instagram: `Write an engaging Instagram caption with emojis and 5-8 relevant hashtags. Include a call to action. Max 2200 characters.`,
    twitter: `Write a Twitter/X thread (3-5 tweets). Each tweet under 280 chars. Number them (1/, 2/, etc). Make it engaging and shareable.`,
    youtube: `Write a YouTube video description. First 2 lines must be compelling. Include timestamps section. Add relevant tags at bottom. 300-500 words.`,
    reels: `Write a short Reels/TikTok script. Include: Hook (0-3s), Main content, CTA. Conversational and energetic. Under 60 seconds when spoken.`,
    whatsapp: `Write a WhatsApp status text. Short, punchy, under 700 characters. Conversational tone. Include 2-3 relevant emojis.`,
    blog: `Create a detailed blog post outline. Include H1, H2, H3 headings. 5-7 main sections. Brief description for each section. SEO-friendly.`,
    email: `Write an email newsletter. Compelling subject line. Preview text. Structured body with sections. Clear CTA at end.`,
  };

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        messages: [{
          role: "user",
          content: `You are a social media expert. Repurpose the following content.

Content: "${content}"
Tone: ${tone}
Platform requirement: ${prompts[platform]}

Write only the platform content. No explanations. Make it ready to publish.`
        }],
      }),
    });

    const data = await response.json();
    const text = data.content?.map(c => c.text || "").join("") || "";
    res.status(200).json({ result: text });
  } catch (err) {
    res.status(500).json({ error: "AI generation failed. Try again." });
  }
}
